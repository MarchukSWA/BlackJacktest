﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static System.Net.Mime.MediaTypeNames;

namespace _4._8_project
{

    public partial class MainWindow : Window
    {
        Random random = new Random();
        List<string> Cards = new List<string>()
        {
            "4C.png", "5C.png", "6C.png"
        };
        
        //List<object> Self_1 = new List<object>()
        //{
        //    new _2a(), new _3a(), new _4a(), new _5a(), new _6a(), new _7a(), new _8a(), new _9a(), new _10a(), new Ja(), new Qa(), new Ka(), new Aa(),
        //    new _2b(), new _3b(), new _4b(), new _5b(), new _6b(), new _7b(), new _8b(), new _9b(), new _10b(), new Jb(), new Qb(), new Kb(), new Ab(),
        //    new _2c(), new _3c(), new _4c(), new _5c(), new _6c(), new _7c(), new _8c(), new _9c(), new _10c(), new Jc(), new Qc(), new Kc(), new Ac(),
        //    new _2d(), new _3d(), new _4d(), new _5d(), new _6d(), new _7d(), new _8d(), new _9d(), new _10d(), new Jd(), new Qd(), new Kd(), new Ad()
        //};

        //List<object> Self_2 = new List<object>()
        //{
        //    new _2a(), new _3a(), new _4a(), new _5a(), new _6a(), new _7a(), new _8a(), new _9a(), new _10a(), new Ja(), new Qa(), new Ka(), new Aa(),
        //    new _2b(), new _3b(), new _4b(), new _5b(), new _6b(), new _7b(), new _8b(), new _9b(), new _10b(), new Jb(), new Qb(), new Kb(), new Ab(),
        //    new _2c(), new _3c(), new _4c(), new _5c(), new _6c(), new _7c(), new _8c(), new _9c(), new _10c(), new Jc(), new Qc(), new Kc(), new Ac(),
        //    new _2d(), new _3d(), new _4d(), new _5d(), new _6d(), new _7d(), new _8d(), new _9d(), new _10d(), new Jd(), new Qd(), new Kd(), new Ad()
        //};

        //List<object> Self_3 = new List<object>()
        //{
        //    new _2a(), new _3a(), new _4a(), new _5a(), new _6a(), new _7a(), new _8a(), new _9a(), new _10a(), new Ja(), new Qa(), new Ka(), new Aa(),
        //    new _2b(), new _3b(), new _4b(), new _5b(), new _6b(), new _7b(), new _8b(), new _9b(), new _10b(), new Jb(), new Qb(), new Kb(), new Ab(),
        //    new _2c(), new _3c(), new _4c(), new _5c(), new _6c(), new _7c(), new _8c(), new _9c(), new _10c(), new Jc(), new Qc(), new Kc(), new Ac(),
        //    new _2d(), new _3d(), new _4d(), new _5d(), new _6d(), new _7d(), new _8d(), new _9d(), new _10d(), new Jd(), new Qd(), new Kd(), new Ad()
        //};

        //List<object> Self_4 = new List<object>()
        //{
        //    new _2a(), new _3a(), new _4a(), new _5a(), new _6a(), new _7a(), new _8a(), new _9a(), new _10a(), new Ja(), new Qa(), new Ka(), new Aa(),
        //    new _2b(), new _3b(), new _4b(), new _5b(), new _6b(), new _7b(), new _8b(), new _9b(), new _10b(), new Jb(), new Qb(), new Kb(), new Ab(),
        //    new _2c(), new _3c(), new _4c(), new _5c(), new _6c(), new _7c(), new _8c(), new _9c(), new _10c(), new Jc(), new Qc(), new Kc(), new Ac(),
        //    new _2d(), new _3d(), new _4d(), new _5d(), new _6d(), new _7d(), new _8d(), new _9d(), new _10d(), new Jd(), new Qd(), new Kd(), new Ad()
        //};

        public MainWindow()
        {
            InitializeComponent();
            //string imagePath = "pack://application:,,,/a7.png"; // Replace with your image file name
            //MyImage.Source = new BitmapImage(new Uri(imagePath));
        }
        //int picture1, picture2;
        public void Click_Hit(object sender, RoutedEventArgs e)
        {
            //int HitCount = 1;

            int RandomCardNumber = random.Next(Cards.Count);
            string RandomCard = Cards[RandomCardNumber];
            Cards.RemoveAt(RandomCardNumber);
            Cards_Self_1.Source = new BitmapImage(new Uri(RandomCard, UriKind.Relative));
            MessageBox.Show(RandomCard);
            //if (HitCount == 1)
            //{
            //    Cards_Self_1.Source = new BitmapImage(new Uri(RandomCard, UriKind.Relative));
            //    HitCount = 2;
            //}
            //else if (HitCount == 2)
            //{
            //    Cards_Self_2.Source = new BitmapImage(new Uri(RandomCard, UriKind.Relative));
            //    HitCount = 3;
            //}

        }
        private void Click_Stand(object sender, RoutedEventArgs e)
        {

        }
    }
}